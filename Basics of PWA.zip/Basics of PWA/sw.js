self.addEventListener("install" , e=> {
    console.log("Install !");
})